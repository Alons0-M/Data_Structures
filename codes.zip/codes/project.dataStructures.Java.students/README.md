# Java library for Data Structures course at University of Málaga. #

This library contains the implementation of the data structures used in the Data Structures course at the University of Málaga.


#### Requires JDK 22 (SDK default) or higher. 

